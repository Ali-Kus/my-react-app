package fr.uga.iut2.genevent.controleur;

public class Create {
    
}
